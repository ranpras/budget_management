"use client"

import {
  BarChart3,
  DollarSign,
  Send,
  TrendingUp,
  Receipt,
  CheckCircle2,
  BookOpen,
  Database,
  Inbox,
  FileText,
  LogOut, // Import LogOut icon
} from "lucide-react"
import { useAuthStore } from "@/lib/auth-store"
import { useMasterDataStore } from "@/lib/master-data-store"

interface SidebarProps {
  currentScreen: string
  onNavigate: (screen: string) => void
}

export function Sidebar({ currentScreen, onNavigate }: SidebarProps) {
  const user = useAuthStore((state) => state.getCurrentUser())
  const { logout } = useAuthStore()
  const masterDataStore = useMasterDataStore()

  const getMenuItems = () => {
    if (!user) return []

    if (user.role === "operator") {
      return [
        { id: "dashboard", label: "Dashboard", icon: BarChart3 },
        { id: "budget-planning", label: "Budget Planning", icon: DollarSign },
        { id: "budget-revision", label: "Budget Revision / Unbudget", icon: TrendingUp },
        { id: "spending-request", label: "Spending Request", icon: Send },
        { id: "actual-realization", label: "Actual Realization", icon: Receipt },
        { id: "my-submissions", label: "My Submissions", icon: FileText },
      ]
    }

    if (user.role === "supervisor") {
      return [
        { id: "dashboard", label: "Dashboard", icon: BarChart3 },
        { id: "approval-inbox", label: "Approval Inbox", icon: Inbox },
        { id: "budget-vs-actual", label: "Monitoring", icon: BarChart3 },
      ]
    }

    if (user.role === "admin_budget") {
      return [
        { id: "dashboard", label: "Dashboard", icon: BarChart3 },
        { id: "finance-approval", label: "Approval Inbox", icon: CheckCircle2 },
        { id: "master-data", label: "Master Data", icon: Database },
        { id: "budget-vs-actual", label: "Budget Monitoring", icon: BarChart3 },
        { id: "transaction-ledger", label: "Audit Log", icon: BookOpen },
      ]
    }

    return []
  }

  const menuItems = getMenuItems()

  const getRoleColor = (role: string) => {
    switch (role) {
      case "operator":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
      case "supervisor":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200"
      case "admin_budget":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200"
    }
  }

  const getUnitName = () => {
    if (!user?.unitId) return ""
    const unit = masterDataStore.units.find((u) => u.id === user.unitId)
    return unit?.name || ""
  }

  return (
    <aside className="w-64 bg-sidebar border-r border-sidebar-border flex flex-col">
      <div className="p-6 border-b border-sidebar-border">
        <h1 className="text-lg font-bold text-sidebar-foreground">Menu</h1>
        <p className="text-xs text-muted-foreground mt-1">Navigation</p>
      </div>

      <nav className="flex-1 p-6 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon
          const isActive = currentScreen === item.id

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive
                  ? "bg-sidebar-primary text-sidebar-primary-foreground"
                  : "text-sidebar-foreground hover:bg-sidebar-accent"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium text-sm">{item.label}</span>
            </button>
          )
        })}
      </nav>

      <div className="p-6 border-t border-sidebar-border space-y-4">
        {/* User Info Card */}
        <div className="bg-sidebar-accent rounded-lg p-4">
          <p className="text-sm font-medium text-sidebar-foreground mb-2">Current User</p>
          <p className="text-sm font-semibold text-sidebar-foreground">{user?.name}</p>
          <div className={`text-xs px-2 py-1 rounded mt-2 inline-block ${getRoleColor(user?.role || "")}`}>
            {user?.role === "admin_budget" ? "ADMIN BUDGET" : user?.role.toUpperCase()}
          </div>
          {user?.unitId && (
            <p className="text-xs text-muted-foreground mt-2">
              Unit: <strong>{getUnitName()}</strong>
            </p>
          )}
        </div>

        {/* Logout Button */}
        <button
          onClick={() => {
            logout()
            window.location.href = "/"
          }}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors text-sidebar-foreground hover:bg-sidebar-accent text-sm font-medium"
        >
          <LogOut className="w-4 h-4" />
          Logout
        </button>
      </div>
    </aside>
  )
}
